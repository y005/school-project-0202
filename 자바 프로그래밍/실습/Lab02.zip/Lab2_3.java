
public class Lab2_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int x=0;x<=10;x++) {
			for(int y=0;y<=10;y++) {
				if(3*x+10*y==100) {
					System.out.println("("+x+","+y+")");	
				}
			}
		}
	}

}
