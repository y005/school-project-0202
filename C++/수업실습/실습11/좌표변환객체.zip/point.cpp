#include <stdio.h>      /* printf */
#include <math.h>       /* atan */
#define PI 3.14159265
#include "point.hpp"

Point::Point(){};
double Point::getX()const{};
double Point::getY()const{};
double Point::getLength()const{};
double Point::getAngle()const{};
void Point::print(){};  

PointXY::PointXY(){x=0;y=0;}
PointXY::PointXY(double x,double y){this->x = x; this->y = y;}
PointXY::PointXY(const PointPolar &a){x = a.getX();y = a.getY();}
PointXY& PointXY::operator=(const PointPolar &a){
	x = a.getX();
	y = a.getY();
	return *this;		
}
double PointXY::getX()const{return x;}
double PointXY::getY()const{return y;}
double PointXY::getLength()const{return sqrt(x*x+y*y);}
double PointXY::getAngle()const{return atan(y/x)*180/PI;}
void PointXY::print(){printf("(%f,%f)\n",x,y);}
 
PointPolar::PointPolar(){length = 0; angle = 0;}
PointPolar::PointPolar(double length, double angle){this->length = length; this->angle =angle;}
PointPolar::PointPolar(const PointXY &a){length = a.getLength();angle = a.getAngle();} 
PointPolar& PointPolar::operator=(const PointXY &a){length = a.getLength();angle = a.getAngle();return *this;}  
double PointPolar::getX()const{ 
	return getLength()*cos(getAngle()*PI/180);
}
double PointPolar::getY()const{
	return getLength()*sin(getAngle()*PI/180);
}
double PointPolar::getLength()const{return length;}
double PointPolar::getAngle()const{return angle;}
void PointPolar::print(){printf("(%f,%f)\n",length,angle);}  // (length, angle)

