class Point;
class PointXY;
class PointPolar;

class Point{
	public:	
		Point();
		virtual double getX()const;
    	virtual double getY()const;
    	virtual double getLength()const;
    	virtual double getAngle()const;
    	virtual void print();  
};

class PointXY : public Point{
    double x, y;
	public :    
    	PointXY();
    	PointXY(double x, double y);
    	PointXY(const PointPolar &a);
    	PointXY& operator=(const PointPolar &a); 
    	double getX()const;
    	double getY()const;
    	double getLength()const;
    	double getAngle()const;
    	void print();  
};

class PointPolar : public Point{
    double length, angle;
	public :
    	PointPolar();
    	PointPolar(double length, double angle);
    	PointPolar(const PointXY &a); 
    	PointPolar& operator=(const PointXY &a);
		double getX()const;
    	double getY()const;
    	double getLength()const;
    	double getAngle()const;
    	void print();  
};
