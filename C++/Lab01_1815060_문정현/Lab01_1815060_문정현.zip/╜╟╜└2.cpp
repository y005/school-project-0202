#include<iostream>
using namespace std;
int main(){
	int num;
	cin>>num;
	if(num%2==0){cout<<"The value "<<num<<" is even number.";}
	else{cout<<"The value "<<num<<" is odd number.";}
}
